//
//  MyLogger4.h
//  MyLogger4
//
//  Created by Roman on 14.11.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for MyLogger4.
FOUNDATION_EXPORT double MyLogger4VersionNumber;

//! Project version string for MyLogger4.
FOUNDATION_EXPORT const unsigned char MyLogger4VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyLogger4/PublicHeader.h>


